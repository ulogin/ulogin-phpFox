<?php
defined('PHPFOX') or exit('NO DICE!');
?>
{$panel}
<script src="//ulogin.ru/js/ulogin.js"></script>