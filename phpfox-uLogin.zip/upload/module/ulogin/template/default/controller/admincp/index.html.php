<?php
header('Location: '. $link_to_settings);
?>