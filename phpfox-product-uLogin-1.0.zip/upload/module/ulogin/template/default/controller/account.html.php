<h3 class="msg">{$message1}</h3>
<div class="small_msg">
    {$message2}
</div>
<noscript>
    <h3>Java script and cookies are required.</h3>
</noscript>
<div class="form_wrap">
    <form action="" method="post" name="ulogin_fields">
        <input class="check_input" type="checkbox" name="ul_im_fields" value="full_name" /><label class="check_label">Полное имя</label><br />
        <input class="check_input" type="checkbox" name="ul_im_fields" value="gender" /><label class="check_label">Пол</label><br />
        <input class="check_input" type="checkbox" name="ul_im_fields" value="birthday" /><label class="check_label">День рождения</label/><br />
        <input class="check_input" type="checkbox" name="ul_im_fields" value="user_image" /><label class="check_label">Фото</label><br />
    </form>
</div>