<?php 
defined('PHPFOX') or exit('NO DICE!'); 
?>
<br/>
<script src="https://ulogin.ru/js/ulogin.js?id=uLogin&display=window&fields={$fields}&redirect_uri={$redirect}"></script>

<div id ="uloginpanel" style="{$style}" onclick = "{$onclick}">
    <a href="#" id="uLogin">
        <img src="https://ulogin.ru/img/button.png" style="width:187px;height:30px"/>
    </a>
</div>