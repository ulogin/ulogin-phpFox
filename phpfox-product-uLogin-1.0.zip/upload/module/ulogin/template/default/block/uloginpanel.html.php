<?php 
    defined('PHPFOX') or exit('NO DICE!');
?>
<br/>
<div id ="uloginpanel" style="{$style}" onclick = "{$onclick}">
    <a href="#" id="uLoginWindow">
        <img src="https://ulogin.ru/img/button.png" style="width:187px;height:30px;"/>
    </a>
</div>

<script src="https://ulogin.ru/js/ulogin.js?id=uLoginWindow&display=window&fields={$fields}&redirect_uri={$redirect}"></script>
