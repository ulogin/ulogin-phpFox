<?php 
defined('PHPFOX') or exit('NO DICE!'); 
?>

{literal}
    <style>
    div#uloginpanel_loginheader
    {
        position: absolute;
        right: 420px;
        top: 25px;
        width: 260px;
        z-index: 9990;
    } 
    </style>
{/literal}
<script src="http://ulogin.ru/js/ulogin.js?id=uLogin&display=window&fields={$fields}&redirect_uri={$redirect}"></script>
<div id ="uloginpanel_loginheader" {if phpfox::getLib('module')->getFullControllerName()=='user.login'} style="position: inherit;border: 1px solid #CFCFCF;margin-top: 5px;width:267px;" {/if}>
    <a href="#" id="uLogin">
        <img src="http://ulogin.ru/img/button.png" style="width:187px;height:30px"/>
    </a>
</div>