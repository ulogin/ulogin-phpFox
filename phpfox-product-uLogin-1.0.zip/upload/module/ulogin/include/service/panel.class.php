<?php
defined('PHPFOX') or exit('NO DICE!');
class uLogin_Service_Panel extends Phpfox_Service
{
    private $_fields = '';
    private $_redirect = '';
    
    public function __construct()
    {
        $this->_fields = 'first_name,last_name,nickname,email,sex,bdate,photo,country,city';
        $this->_redirect = urlencode(Phpfox::getLib('url')->makeUrl('ulogin',array('token')));
    }
    
    public function getRedirectUrl(){
        return $this->_redirect;
    }
    
    public function  getFields(){
        return $this->_fields;
    }


    public function showPanel()
    {
        Phpfox::getBlock('ulogin.uloginpanel',array());
    }
}
?>
