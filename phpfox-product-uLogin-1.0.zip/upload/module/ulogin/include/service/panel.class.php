<?php
defined('PHPFOX') or exit('NO DICE!');
class uLogin_Service_Panel extends Phpfox_Service
{
    private $_fields = '';
    
    public function __construct()
    {
        $this->_fields = 'first_name,last_name,nickname,email,sex,bdate,photo,photo_big,country,city';

    }
    
    public function getLoginRedirectUrl(){
        return urlencode(Phpfox::getLib('url')->makeUrl('ulogin',array('token')));
    }
    
    public function getAttachRedirectUrl(){
        //Phpfox::getUserField($sAlias);
        return urlencode(Phpfox::getLib('url')->makeUrl('ulogin',array('attach')));
    }
    
    public function  getFields(){
        return $this->_fields;
    }


    public function showPanel()
    {
        Phpfox::getBlock('ulogin.uloginpanel',array());
    }
}
?>
