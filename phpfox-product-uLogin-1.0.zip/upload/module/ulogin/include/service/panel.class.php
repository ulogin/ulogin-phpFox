<?php
defined('PHPFOX') or exit('NO DICE!');
class uLogin_Service_Panel extends Phpfox_Service
{
    private $_fields = '';
    
    public function __construct()
    {
        $this->_fields = 'first_name,last_name,nickname,email,sex,bdate,photo,photo_big,country,city';

    }
    
    public function getLoginRedirectUrl(){
        return urlencode(Phpfox::getLib('url')->makeUrl('ulogin',array('token')));
    }
    
    public function getAttachRedirectUrl(){
        //Phpfox::getUserField($sAlias);
        return urlencode(Phpfox::getLib('url')->makeUrl('ulogin',array('attach')));
    }
    
    public function  getFields(){
        return $this->_fields;
    }


    public function showPanel()
    {
        if (Phpfox::getLib('module')->getFullControllerName() == 'user.login')
            Phpfox::getBlock('ulogin.uloginpanel',array());
        else{
            $fields = phpfox::getService('ulogin.panel')->getFields();
            $redirect = phpfox::getService('ulogin.panel')->getLoginRedirectUrl();
            echo '<script src="https://ulogin.ru/js/ulogin.js?id=uLogin&display=window&fields='.$fields.'&redirect_uri='.$redirect.'"></script>'.
                 '<a href="#" id="uLogin"><img src="https://ulogin.ru/img/button.png" style="width:187px;height:30px"/></a>';
        }
        
    }
}
?>
