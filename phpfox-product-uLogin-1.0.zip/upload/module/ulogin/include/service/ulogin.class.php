<?php

defined('PHPFOX') or exit('NO DICE!');

class uLogin_Service_uLogin extends Phpfox_Service
{
    /*
     * 
     */
    private $_user = array();
    private $_unique = array();
    private $_error = '';
    /*
     * 
     */
    public function getUserFromToken($token){
        $this->_user = array();
        $this->_unique = array();
        $this->_error = '';
        if (function_exists('file_get_contents')){
            for($try = 0 ; $try < 5; $try ++){
                $data = file_get_contents('http://ulogin.ru/token.php?token='.$token."&host=".Phpfox::getLib('url')->makeUrl(''));
                $data = json_decode($data, true);
                if (isset($data['error']) || isset($data['uid']))
                    break;
            }
            
            if (isset($data['error']))
                $this->_error = $data['error'];
            else if(isset($data['uid'])){
                $this->_user = $data;
                $this->_user['token'] = $token;
            }else{
                
                
                    $this->_error = 'Unknown error';
            }
        }else{
            $this->_error = 'Function file_get_contents does not exist';
        }
    }

    /*
     * 
     */
    public function checkUser()
    {
        $exist = true;
        $rows = $this->database()->select('u.uid, u.token') 
                    ->from(Phpfox::getT('ulogin_user'), 'u') 
                    ->where('u.identity = \''.$this->database()->escape($this->_user['identity']) .'\'')
                    ->execute('getRow');
        
        if (isset($rows['uid']))
            $this->_unique = array('uid' => $rows['uid'],'token' => $rows['token']);
        else 
            $exist = false;
        
        if (isset($this->_unique['uid'])){
            $rows = $this->database()->select('u.user_name') 
                                ->from(Phpfox::getT('user'), 'u') 
                                ->where('u.user_id = '.$this->_unique['uid'])
                                ->execute('getRow');
                if (!isset($rows['user_name'])){
                $this->database()->delete(Phpfox::getT('ulogin_user'), 'identity = \''.$this->database()->escape($this->_user['identity']) .'\'');
                $this->_unique['uid'] = 0;
                $exist = false;   
            }
        }else 
            $exist = false;
        return $exist;
    }
    
    /*
     * 
     */
    public function loginUser()
    {
        Phpfox::getLib('session')->set('cache_user_id', $this->_unique['uid']); 
        
        if ($Plugin = Phpfox_Plugin::get('user.service_auth_login__cookie_start')){
            eval($Plugin);
        }
        
        $user_data = $this->database()->select('password, password_salt, user_name')
                                        ->from(Phpfox::getT('user'))
                                        ->where('user_id = ' . $this->_unique['uid'])
                                        ->execute('getRow');
        
        if (!isset($user_data['password'])){
            $this->_error = 'Unknown error';
            return;
        }
        
        $passwordHash = Phpfox::getLib('hash')->setRandomHash(Phpfox::getLib('hash')->setHash($user_data['password'], $user_data['password_salt']));
        Phpfox::setCookie('user_id',$this->_unique['uid'], 0);
        Phpfox::setCookie('user_hash', $passwordHash, 0);
        $this->database()->update(Phpfox::getT('user'), array('last_login' => PHPFOX_TIME), 'user_id = ' . $this->_unique['uid']);	
	$this->database()->insert(Phpfox::getT('user_ip'), array(
                                                            'user_id' => $this->_user['uid'],
                                                            'type_id' => 'login',
                                                            'ip_address' => Phpfox::getIp(),
                                                            'time_stamp' => PHPFOX_TIME
                                                            )
			);	
        
        if ($Plugin = Phpfox_Plugin::get('user.service_auth_login__cookie_end')){
                eval($Plugin);
        }
        
        return $user_data['user_name'];
    }
    
    /*
     * 
     */
    public function createNewUser(){
        if ($this->_checkEmail() > 0){
            $this->_error = 'Invalid email';
            return;
        }
        $bdate = explode('.', $this->_user['bdate']);
        $password = md5($this->_user['uid'].$this->_user['token']);
        $salt = $this->_getSalt(7);
        $password = Phpfox::getLib('hash')->setHash($password, $salt);
        $username = $this->_generateName($this->_user['nickname']);
        $uid = $this->database()->insert(Phpfox::getT('user'), array(
                    'email' => $this->database()->escape($this->_user['email']),
                    'full_name' => $this->database()->escape($this->_user['first_name'].' '.$this->_user['last_name']),
                    'user_name' => $this->database()->escape($username),
                    'user_group_id' => '2',
                    'gender' => $this->_user['sex'] == '2' ? '1' : '2',
                    'birthday' => (intval($bdate[1]) < 10 ? '0'.intval($bdate[1]) : $bdate[1]) . (intval($bdate[0]) < 10 ? '0'.intval($bdate[0]) : $bdate[0]) . $bdate[2],
                    'joined' => time(),
                    'password_salt' => $salt,
                    'password' => $password
                   )
        );
       
        
        if ($uid){
            $this->database()->insert(Phpfox::getT('user_activity'),array('user_id'=>$uid));
            $this->database()->insert(Phpfox::getT('user_field'),array('user_id'=>$uid));
            $this->database()->insert(Phpfox::getT('user_space'),array('user_id'=>$uid));
            $this->database()->insert(Phpfox::getT('user_count'),array('user_id'=>$uid));
            $this->database()->insert(Phpfox::getT('ulogin_user'),array('uid'=>$uid, 'identity'=>$this->database()->escape($this->_user['identity']),'token'=>$this->_user['token']) );
            $photo_url = $this->_user['photo_big'] == 'http://ulogin.ru/img/photo_big.png' ? $this->_user['photo'] : $this->_user['photo_big'];
            if ($photo = $this->_uploadPhoto($photo_url, $uid)){
                $this->database()->update(Phpfox::getT('user'), array('user_image' => $photo), 'user_id = ' . $uid);	
            }
            $this->_unique['token'] = $this->_user['token'];
            $this->_unique['uid'] = $uid;
        } else{
            $this->_error = 'User creation error';
        }
    }
    
    /*
     * 
     */
    public function getError(){
        return $this->_error;
    }
    
    /*
     * 
     */
    public function syncUser($fields){
        
        if (isset($this->_user['uid']) && Phpfox::getUserId()){
            
            if ($this->checkUser()){
                
                $ulogin_id = $this->_user['uid'];
                
                if (intval($this->_unique['uid']) != Phpfox::getUserId() ) {
                    $this->database()->update( Phpfox::getT('ulogin_user'), array('uid'=>  Phpfox::getUserId()) , 'identity =\'' . $this->database()->escape($this->_user['identity']).'\'' );
                    $this->database()->delete( Phpfox::getT('user'), 'user_id = '.intval($this->_unique['uid']));
                    $this->database()->delete( Phpfox::getT('user_activity'), 'user_id = '.intval($this->_unique['uid']));
                    $this->database()->delete( Phpfox::getT('user_field'), 'user_id = '.intval($this->_unique['uid']));
                    $this->database()->delete( Phpfox::getT('user_space'), 'user_id = '.intval($this->_unique['uid']));
                    $this->database()->delete( Phpfox::getT('user_count'), 'user_id = '.intval($this->_unique['uid']));
                }
                
                if (count($fields) > 0){
                    $update_fields = array();

                    foreach ($fields as $field){
                        switch ($field) {
                            case 'full_name':
                                $update_fields[$field] =  $this->database()->escape($this->_user['first_name'].' '.$this->_user['last_name']);
                            break;
                            case 'gender':
                                 $update_fields[$field] = $this->_user['sex'] == '2' ? '1' : '2';
                            break;
                            case 'email':
                                if ($this->_checkEmail())
                                    $update_fields[$field] = $this->database()->escape($this->_user['email']);
                            break;
                            case 'birthday':
                                $bdate = explode('.', $this->_user['bdate']);
                                 $update_fields[$field] = (intval($bdate[1]) < 10 ? '0'.intval($bdate[1]): $bdate[1] ) . (intval($bdate[0]) < 10 ? '0'.intval($bdate[0]) : $bdate[0]) . $bdate[2];
                            break;
                            case 'user_image':
                                $photo_url = $this->_user['photo_big'] == 'http://ulogin.ru/img/photo_big.png' ? $this->_user['photo'] : $this->_user['photo_big'];
                                if ($photo = $this->_uploadPhoto($photo_url, Phpfox::getUserId())){
                                    $update_fields[$field] = $photo;
                                }
                            break;
                        }

                    }

                    $this->database()->update(Phpfox::getT('user'), $update_fields, 'user_id = ' . Phpfox::getUserId());	
            }
                
            }else{
                
                $ulogin_id = $this->database()->insert(Phpfox::getT('ulogin_user'),array('uid'=>Phpfox::getUserId(), 'identity'=>$this->database()->escape($this->_user['identity']),'token'=>$this->_user['token']) );
                
                if (count($fields) > 0){
                    $update_fields = array();

                    foreach ($fields as $field){
                        switch ($field) {
                            case 'full_name':
                                $update_fields[$field] =  $this->database()->escape($this->_user['first_name'].' '.$this->_user['last_name']);
                            break;
                            case 'gender':
                                 $update_fields[$field] = $this->_user['sex'] == '2' ? '1' : '2';
                            break;
                            case 'birthday':
                                $bdate = explode('.', $this->_user['bdate']);
                                 $update_fields[$field] = (intval($bdate[1]) < 10 ? '0'.intval($bdate[1]) : $bdate[1] ) . (intval($bdate[0]) < 10 ? '0'.$bdate[0] : $bdate[0]) . $bdate[2];
                            break;
                            case 'user_image':
                                $photo_url = $this->_user['photo_big'] == 'http://ulogin.ru/img/photo_big.png' ? $this->_user['photo'] : $this->_user['photo_big'];
                                if ($photo = $this->_uploadPhoto($photo_url, Phpfox::getUserId())){
                                    $update_fields[$field] = $photo;
                                }
                            break;
                        }
                    }
                }
                
                $this->database()->update(Phpfox::getT('user'), $update_fields, 'user_id = ' . Phpfox::getUserId());	
            }
            
            return $ulogin_id;
        }
    }
    
    /*
     * 
     */
    private function _generateName($name){
        $user = Phpfox::getService('user');
        $exist = $user->getByUserName($name);
        $newName = $name;
        while ($exist){
            $newName = $name.'_'.rand(1,1000);
            $exist = $user->getByUserName($newName);
        }
        return $newName;
    }
    
    /*
     * 
     */
    private function _checkEmail(){
        $id = 0;
        $row = $this->database()->select('user_id') 
                    ->from(Phpfox::getT('user')) 
                    ->where('email = \''.$this->database()->escape($this->_user['email']).'\'')
                    ->execute('getRow'); 
        $id = isset($row['user_id']) ? $row['user_id'] : 0;
        return $id;
    }
    
    /*
     * 
     */
    private function _getSalt($iTotal = 3)
    {
	$sSalt = '';
	for ($i = 0; $i < $iTotal; $i++)
	{
		$sSalt .= chr(rand(33, 91));
	}
	return $sSalt;
    }  
    
    /*
     * 
     */
    private function _uploadPhoto($url, $filename){
        
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_NOBODY, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_HEADER, 1); 
        $result = curl_exec($ch);
        
        if (!$result)
            return false;

        preg_match('/Content-Type: \w+(\/)(?<value>\w+)/', $result, $value);
        $ext = $value['value'] == 'jpeg' ? 'jpg' : $value['value'];
        
        $savepath = PHPFOX_DIR_FILE .'pic' . PHPFOX_DS . 'user' . PHPFOX_DS .$filename.'.'.$ext;
        
        $from = fopen($url,'rb'); 
        $to = fopen($savepath, "wb");
        $size = 0;
        if ($from && $to){
            while(!feof($from)) {
                $size += fwrite($to, fread($from, 1024 * 8 ), 1024 * 8 );
            }
        } else 
            return false;

        fclose($from); 
        fclose($to);
        
        return $filename.'.'.$ext;
    }
    
}

?>
