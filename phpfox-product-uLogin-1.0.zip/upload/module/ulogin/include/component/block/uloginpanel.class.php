<?php
defined('PHPFOX') or exit('NO DICE!');

class uLogin_Component_Block_Uloginpanel extends Phpfox_Component
{
	public function process()
	{
            if (Phpfox::getLib('module')->getFullControllerName() == 'ulogin.account') {
                $this->template()->assign(array('redirect'=>  Phpfox::getService('ulogin.panel')->getAttachRedirectUrl(), 
                                                'fields' => Phpfox::getService('ulogin.panel')->getFields(),
                                                'style' => '',
                                                'onclick' => 'attach()'
                                                ));
            }else {
                if (Phpfox::getLib('module')->getFullControllerName() == 'user.login')
                    //$style = "position: inherit;border: 1px solid #CFCFCF;margin-top: 5px;width:267px;";
                    $style = "margin-top: 10px;width:187px;height:30px";
                else
                    $style = "position: absolute;right: 440px;top: 40px;width: 187px;height:30px;z-index: 100;";
                $this->template()->assign(array('redirect'=>  Phpfox::getService('ulogin.panel')->getLoginRedirectUrl(), 
                                                'fields' => Phpfox::getService('ulogin.panel')->getFields(),
                                                'style' => $style,
                                                'onclick' => ''
                                        ));
            }
            return 'block';
        }
}
?>
