<?php
defined('PHPFOX') or exit('NO DICE!');

class uLogin_Component_Block_Uloginpanel extends Phpfox_Component
{
	public function process()
	{
            $this->template()->assign(array('redirect'=>  Phpfox::getService('ulogin.panel')->getRedirectUrl(), 'fields' => Phpfox::getService('ulogin.panel')->getFields()));
        }
}
?>
