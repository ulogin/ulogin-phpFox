<?php
class uLogin_Component_Controller_Attach extends Phpfox_Component
{
    public function process()
    {  
        $url = Phpfox::getLib('url');
        $this->template()->assign('message', '');
        $cookie = Phpfox::getCookie('ul_attach_hash');
        $hash = md5(Phpfox::getUserId().Phpfox::getIp().Phpfox::getUserField('email').Phpfox::getUserField('user_name'));
        
        if (($hash == $cookie) && isset($_POST['token']) && (Phpfox::getUserId() != 0)){
            
            $fields = isset($_COOKIE['ul_import_fields']) && !empty($_COOKIE['ul_import_fields']) ? explode(',',$_COOKIE['ul_import_fields']) : array();
            
            Phpfox::setCookie('ul_attach_hash', '', time() - 3600);
            setcookie('ul_import_fields', '', time() - 3600);
            
            $uLogin = Phpfox::getService('ulogin'); 
            $uLogin->getUserFromToken($_POST['token']);
            $error = $uLogin->getError();
            
            if (empty($error)){
                $uLogin->syncUser($fields);
            }else{
                $this->template()->assign('message', $error);
            }
            
            $url->send($url->makeUrl(''));
        }
        else{
            $this->template()->assign('message', 'No cookies');
            Phpfox::setCookie('ul_attach_hash', '', time() - 3600);
            setcookie('ul_import_fields', '', time() - 3600);
            $url->send($url->makeUrl(''));
        }
        
    }
}
?>
