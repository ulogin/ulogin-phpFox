<?php

class uLogin_Component_Controller_Account extends Phpfox_Component
{
    public function process()
    {  
        Phpfox::setCookie('ul_attach_hash', md5(Phpfox::getUserId().Phpfox::getIp().Phpfox::getUserField('email').Phpfox::getUserField('user_name')), 0);
        $this->template()->setTitle('uLogin account settings'); 
        $this->template()->setBreadcrumb('uLogin account settings'); 
        $this->template()->assign(array('message1'=>'Синхронизация профилей uLogin', 'message2'=>'Выберите поля для импорта и залогинтесь через uLogin:'));
        $this->template()->setHeader(array( 
                'account.css' => 'module_ulogin', 
                'account.js' => 'module_ulogin' 
            )
        ); 
    }
}
?>
