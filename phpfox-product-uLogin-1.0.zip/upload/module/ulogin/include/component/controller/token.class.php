<?php
class uLogin_Component_Controller_Token extends Phpfox_Component
{
    public function process()
    {         
        $url = Phpfox::getLib('url');
        $this->template()->assign('message', '');
        if (isset($_POST['token']) && (Phpfox::getUserId() == 0)){

            $uLogin = Phpfox::getService('ulogin'); 
            $uLogin->getUserFromToken($_POST['token']);
            $error = $uLogin->getError();
            
            if (empty($error)){
                
                if ($uLogin->checkUser()){
                    $url->send($url->makeUrl($uLogin->loginUser()));
                }else{
                    $uLogin->createNewUser();
                    $error = $uLogin->getError();
                    if (empty($error)){
                        $url->send($url->makeUrl($uLogin->loginUser()));
                    }else
                        $this->template()->assign('message', $error);
                }
                
            }else{
                $this->template()->assign('message', $error);
            }
        }else{
            $this->template()->assign('message', 'No token? Go away!');
            $url->send($url->makeUrl(''));
        }
         
    }
}

?>
